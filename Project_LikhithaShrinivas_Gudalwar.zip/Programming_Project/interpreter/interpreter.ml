type typ =
  | TBool
  | TInt
  | TArrow of typ * typ

type exp =
  | True
  | False
  | If of exp * exp * exp
  | Num of int
  | IsZero of exp
  | Plus of exp * exp
  | Mult of exp * exp
  | Var of string
  | Lambda of string * typ * exp
  | Apply of exp * exp
  | LambdaRec of string * typ * typ * string * exp
  | Div of exp * exp
  | Try of exp * exp
  | RaiseDivByZero of typ * exp

type type_environment = (string * typ) list

exception Eval_error
exception Type_error
exception Substitution_error

let rec free_variables (e : exp) : string list =
  let rec union acc = function
    | [] -> acc
    | h :: t -> union
                  (if List.exists (fun x -> x = h) acc then acc else h :: acc)
                  t in
  match e with
  | True -> []
  | False -> []
  | Num _ -> []
  | IsZero exp -> free_variables exp
  | Plus(e1, e2) | Mult(e1, e2) | Div(e1, e2) | Try(e1, e2) ->
     union (free_variables e1) (free_variables e2)
  | If(e1, e2, e3) ->
     union
       (free_variables e1)
       (union (free_variables e2) (free_variables e3))
  | Var x -> [x]
  | Lambda(v, _, exp) ->
     List.filter
       (fun x -> not (String.equal x v))
       (free_variables exp)
  | Apply(fn, exp) -> union (free_variables fn) (free_variables exp)
  | LambdaRec(name, _, _, v, exp) ->
     List.filter
       (fun x -> not (String.equal x v) && not (String.equal x name))
       (free_variables exp)
  | RaiseDivByZero(_, exp) -> free_variables exp

let rec rename_var (v : string) (e : exp) (excluded : string list) =
  let rec loop n =
    if List.exists (fun x -> n = x) excluded then
      loop (n ^ "x")
    else
      n, substitution e v (Var n) in
  loop v
and substitution (e1 : exp) (x : string) (e2 : exp) = match e1 with
  | True -> e1
  | False -> e1
  | Num _ -> e1
  | IsZero exp -> IsZero(substitution exp x e2)
  | Plus(a, b) -> Plus(substitution a x e2, substitution b x e2)
  | Mult(a, b) -> Mult(substitution a x e2, substitution b x e2)
  | Div(a, b) -> Div(substitution a x e2, substitution b x e2)
  | If(cond, a, b) ->
                     If(substitution cond x e2, substitution a x e2, substitution b x e2)
  | Var v -> if v = x then e2 else e1
  | Lambda(v, typ, exp) ->
                       let nv, nexp = rename_var v exp (free_variables e2) in
                         Lambda(nv,
                                  typ,
                                     if nv = x then
                                                   nexp
                                                       else
                                                           substitution nexp x e2)
  | Apply(fn, exp) -> Apply(substitution fn x e2, substitution exp x e2)
  | LambdaRec(name, typ1, typ2, var, exp) ->
                                     if x = var || x = name then
                                                    e1
                                     else if List.exists (fun v -> v = var || v = name) (free_variables e2) then
                                                raise Substitution_error
                                     else
                                              LambdaRec(name, typ1, typ2, var, substitution exp x e2)
  | Try(a, b) -> Try(substitution a x e2, substitution b x e2)
  | RaiseDivByZero(t, e) -> RaiseDivByZero(t, substitution e x e2)

let rec step (e : exp) : exp = match e with
  | If(RaiseDivByZero(typ, exp), _, _) | IsZero(RaiseDivByZero(typ, exp)) ->
                                                                      RaiseDivByZero(typ, exp)
  | If(True, exp, _) -> exp
  | If(False, _, exp) -> exp
  | If(cond, e1, e2) -> If(step cond, e1, e2)
  | IsZero(Num 0) -> True
  | IsZero(Num _) -> False
  | IsZero(exp) -> IsZero(step exp)
  | Plus(Num a, Num b) -> Num(a + b)
  | Plus(Num a, exp) -> Plus(Num a, step exp)
  | Plus(a, b) -> Plus(step a, b)
  | Mult(Num a, Num b) -> Num(a * b)
  | Mult(Num a, exp) -> Mult(Num a, step exp)
  | Mult(a, b) -> Mult(step a, b)
  | Div(Num n, Num 0) -> RaiseDivByZero(TInt, Num n)
  | Div(Num n, Num d) -> Num(n / d)
  | Div(Num n, exp) -> Div(Num n, step exp)
  | Div(n, d) -> Div(step n, d)
  | Apply(Lambda(v, typ, e1), e2) -> substitution e1 v e2
  | Apply(LambdaRec(name, t1, t2, v, e1), e2) ->
                                              substitution (substitution e1 v e2) name (LambdaRec(name, t1, t2, v, e1))
  | Apply(e1, e2) -> Apply(step e1, e2)
  | Try(e1, e2) -> (match e1 with
                   | True | False | Num _ | Lambda _ | LambdaRec _ -> e1
                   | RaiseDivByZero(_, n) -> Apply(e2, n)
                   | _ -> Try(step e1, e2))
  | RaiseDivByZero(typ, exp) -> RaiseDivByZero(typ, step exp)
  | _ -> raise Eval_error

let rec multi_step (e : exp) : exp = (match e with
  | True -> e
  | False -> e
  | Num _ -> e
  | Lambda _ -> e
  | LambdaRec _ -> e
  | RaiseDivByZero(typ, exp) -> (match exp with
                                | True -> e
                                | False -> e
                                | Num _ -> e
                                | Lambda _ -> e
                                | LambdaRec _ -> e
                                | _ -> RaiseDivByZero(typ, multi_step exp))
                                | _ -> multi_step (step e))

let rec type_check (te : type_environment) (e : exp) : typ =
  let rec var_type x = function
    | [] -> raise Type_error
    | (v,  typ) :: t -> if v = x then typ else var_type x t in
  match e with
  | True -> TBool
  | False -> TBool
  | Num _ -> TInt
  | IsZero exp -> if (type_check te exp) = TInt then TBool else raise Type_error
  | Plus(e1, e2) | Mult(e1, e2) | Div(e1, e2) ->
                              if (type_check te e1) = TInt && (type_check te e2) = TInt then
                                          TInt
                            else
                                raise Type_error
  | If(cond, e1, e2) -> if (type_check te cond) = TBool then
                          let t = type_check te e1 in
                          if t = type_check te e2 then t else raise Type_error
                        else
                          raise Type_error
  | Var x -> var_type x te
  | Lambda(v, typ, exp) ->
                          let v, exp = rename_var v exp (List.map fst te) in
                                TArrow(typ, type_check ((v, typ) :: te) exp)
  | Apply(fn, exp) -> (match type_check te fn with
                      | TArrow(vtype, etype) -> if vtype = (type_check te exp) then etype else raise Type_error
                      | _ -> raise Type_error)
  | LambdaRec(name, t1, t2, v, exp) ->
                                      let nte = (v, t1) :: (name, TArrow(t1, t2)) :: te in
                                                  TArrow(t1, type_check nte exp)
  | Try(e1, e2) -> let t1 = type_check te e1 in
                     (match type_check te e2 with
                     | TArrow(_, t2) -> if t1 = t2 then t1 else raise Type_error
                     | _ -> raise Type_error)
  | RaiseDivByZero(t, _) -> t
