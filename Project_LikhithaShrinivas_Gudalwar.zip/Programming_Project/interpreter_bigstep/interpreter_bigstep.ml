type exp =
  | True
  | False
  | If of exp * exp * exp
  | Num of int
  | IsZero of exp
  | Plus of exp * exp
  | Mult of exp * exp

  let rec string_of_exp (e : exp) : string = match e with
  | True -> "true"
  | False -> "false"
  | If (exp_a,exp_b,exp_c) -> "if " ^ (string_of_exp exp_a) ^ " then " ^ (string_of_exp exp_b) ^ " else " ^ (string_of_exp exp_c)
  | Num e -> string_of_int e
  | IsZero (exp_z) -> "(" ^ "isZero " ^ (string_of_exp exp_z) ^ ")"
  | Plus (a, b) -> "(" ^ (string_of_exp a) ^ " + " ^ (string_of_exp b) ^ ")"
  | Mult (x, y) -> "(" ^ (string_of_exp x) ^ " * " ^ (string_of_exp y) ^ ")"

   exception Eval_error

   let rec eval (e : exp) : exp = match e with 
  | True -> True
  | False -> False
  | If (exp_a, exp_b, exp_c) -> if (eval exp_a = True) then (eval exp_b) else (eval exp_c)
  | Num e -> Num e
  | IsZero z -> if (eval z = True) || (eval z = False) then raise Eval_error else (if (eval z = Num 0) then True else False)
  | Plus (a, b) -> (match eval a with
                    | Num a -> (match eval b with
                      | Num b -> Num (a + b)
                      | _ -> raise Eval_error)
                    | _ -> raise Eval_error)
  | Mult (x, y) -> (match eval x with
                    | Num x -> (match eval y with
                      | Num y -> Num (x * y)
                      | _ -> raise Eval_error)
                    | _ -> raise Eval_error)
