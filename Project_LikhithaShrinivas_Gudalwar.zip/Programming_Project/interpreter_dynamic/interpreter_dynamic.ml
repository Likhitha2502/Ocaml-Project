type typ =
  | TBool
  | TInt
  | TArrow of typ * typ

type exp =
  | True
  | False
  | If of exp * exp * exp
  | Num of int
  | IsZero of exp
  | Plus of exp * exp
  | Mult of exp * exp
  | Var of string
  | Lambda of string * exp
  | Apply of exp * exp
  | Let of string * exp * exp
  | TypeError

type environment = (string * exp) list

exception Eval_error

let rec step (env : environment) (e : exp) : (environment * exp) =
  let rec lookup v = function
    | [] -> TypeError
    | (x, e) :: t -> if x = v then e else lookup v t in
  match e with
  | If(True, exp, _) -> env, exp
  | If(False, _, exp) -> env, exp
  | If(e1, e2, e3) -> (match e1 with
                        | Num _ -> env, TypeError
                        | Lambda _ -> env, TypeError
                        | TypeError -> env, TypeError
                        | _ -> let env, exp = step env e1 in env, If(exp, e2, e3))
  | IsZero(Num 0) -> env, True
  | IsZero(Num _) -> env, False
  | IsZero(exp) -> (match exp with
                   | True -> env, TypeError
                   | False -> env, TypeError
                   | Lambda _ -> env, TypeError
                   | TypeError -> env, TypeError
                   | _ -> let env, exp = step env exp in env, IsZero exp)
  | Plus(Num a, Num b) -> env, Num(a + b)
  | Plus(Num a, exp) -> (match exp with
                        | True -> env, TypeError
                        | False -> env, TypeError
                        | Lambda _ -> env, TypeError
                        | TypeError -> env, TypeError
                        | _ -> let env, exp = step env exp in env, Plus(Num a, exp))
  | Plus(e1, e2) -> (match e1 with
                    | True -> env, TypeError
                    | False -> env, TypeError
                    | Lambda _ -> env, TypeError
                    | TypeError -> env, TypeError
                    | _ -> let env, e1 = step env e1 in env, Plus(e1, e2))
  | Mult(Num a, Num b) -> env, Num(a * b)
  | Mult(Num a, exp) -> (match exp with
                        | True -> env, TypeError
                        | False -> env, TypeError
                        | Lambda _ -> env, TypeError
                        | TypeError -> env, TypeError
                        | _ -> let env, exp = step env exp in env, Mult(Num a, exp))
  | Mult(e1, e2) -> (match e1 with
                    | True -> env, TypeError
                    | False -> env, TypeError
                    | Lambda _ -> env, TypeError
                    | TypeError -> env, TypeError
                    | _ -> let env, e1 = step env e1 in env, Mult(e1, e2))
  | Apply(Lambda(v, e1), e2) -> (match e2 with
                                | Num _ -> (v, e2) :: env, e1
                                | True -> (v, e2) :: env, e1
                                | False -> (v, e2) :: env, e1
                                | Lambda _ -> (v, e2) :: env, e1
                                | TypeError -> env, TypeError
                                | _ -> let env, e2 = step env e2 in env, Apply(Lambda(v, e1), e2))
  | Apply(e1, e2) -> (match e1 with
                     | Num _ -> env, TypeError
                     | True -> env, TypeError
                     | False -> env, TypeError
                     | _ -> let env, e1 = step env e1 in env, Apply(e1, e2))
  | Var x -> env, lookup x env
  | Let(v, e1, e2) -> env, Apply(Lambda(v, e2), e1)
  | _ -> raise Eval_error

let rec multi_step (env : environment) (e : exp) : (environment * exp) = match e with
  | True -> env, e
  | False -> env, e
  | Num _ -> env, e
  | Lambda _ -> env, e
  | TypeError -> env,e
  | _ -> let env, e = step env e in multi_step env e
